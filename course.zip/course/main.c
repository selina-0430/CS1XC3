/**
 * @file main.c
 * @author Selina Kim (kim391@mcmaster.ca)
 * @brief Demonstrates the Course and Student objects and functions involving these objects
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Demonstrates the Course and Student objects and functions involving these objects
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL));

  // Creates a Course object
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // enrolls 20 randomly generated Student objects with 8 grades to MATH101 Course object
  for (int i = 0; i < 20; i++)
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  // prints the top student (highest average) of the course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // finds and prints all students passing the course
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); // loops through all students in list of passing students of course
  
  return 0;
}