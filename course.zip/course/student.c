/**
 * @file student.c
 * @author Selina Kim (kim391@mcmaster.ca)
 * @brief Defines the functions that involve using a Student object
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to the dynamically allocated array of grades of the passed in student object
 * 
 * @param student a Student object
 * @param grade a double that stores a grade that will be assigned to the Student object
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;

  // if this is the first time adding a grade to the student, make space in the heap from scratch using calloc
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));

  // reallocate the block of memory of the grades array by using realloc so it can hold one more double
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculates the average grade of passed in student object
 * 
 * @param student a Student object
 * @return double that contains the average grade of the student
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; // add every grade of student to a total variable
  return total / ((double) student->num_grades);
}

/**
 * @brief Converts all attributes of passed in student object into a string and prints
 * 
 * @param student the Student object that will be printed
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) // prints every single grade in the array of grades
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Generates a random Student object with a number of grades based on the passed in int value
 * 
 * @param grades an int value that stores the number of grades that will be assigned to each generated Student object
 * @return Student* a randomly generated student object
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student)); // making space in memory for one Student object

  strcpy(new_student->first_name, first_names[rand() % 24]); // assigning random first and last name to the Student object
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // converts ASCII character to a single digit number and repeats 10 times to generate a 10-digit id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); // adds a grade to the student object with a minimum floor of 25
  }

  return new_student;
}