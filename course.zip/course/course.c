/**
 * @file course.c
 * @author Selina Kim (kim391@mcmaster.ca)
 * @brief Defines the functions that involve using a Course object
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Adds the passed in student object to the passed in course object
 * 
 * @param course a Course object
 * @param student a Student object that will be enrolled to the course
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); // if this is the first time adding a Student object, make space in heap from scratch by using calloc
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); // reallocate the block of memory of the Student array by using realloc so it can hold one more Student object
  }
  course->students[course->total_students - 1] = *student; 
}

/**
 * @brief Converts all attributes of Course object to a string and prints
 * 
 * @param course a Course object that will have its attributes be printed
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) // for all students in the course, convert and print their attributes
    print_student(&course->students[i]);
}

/**
 * @brief Finds the student with the highest average in the course
 * 
 * @param course a Course object
 * @return Student* object with highest average of course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0]; // student pointer points to the memory address of first student in course
 
  for (int i = 1; i < course->total_students; i++) // loop through all students in Course object
  {
    student_average = average(&course->students[i]);

    // if the current student's average is higher than the maximum average so far, re-assign the maximum average as the current student's average
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief returns a list of Student objects that are passing the course and stores the number of passing students in passed in int parameter
 * 
 * @param course a Course object
 * @param total_passing a pointer that will store the number of students passing
 * @return Student* an array of student objects that have passed the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) // loops through all student objects of passed in course object
    if (average(&course->students[i]) >= 50) count++; // if current student has a grade average greater than or equal to 50, add 1 to the counter
  
  passing = calloc(count, sizeof(Student)); // creates space in heap for the number of Student objects of count variable

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i]; // assign the current student object to current index of passing array
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}