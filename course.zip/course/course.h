/**
 * @file course.h
 * @author Selina Kim (kim391@mcmaster.ca)
 * @brief A custom library containing the typedef struct of Course
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Defines a _course struct as a Course typdef with attributes: name, code, students, total students
 */
typedef struct _course 
{
  char name[100]; /**< the course title */
  char code[10]; /**< the course code */
  Student *students; /**< the list of students in the course */
  int total_students; /**< the number of students in the course */
} Course;

// Pre-defining functions
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


